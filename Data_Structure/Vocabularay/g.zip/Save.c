#include "head.h"

void Save(BTreeNode *bt, char *tmp, FILE *fp)
{
	if(bt==NULL)
		return ;

	tmp[strlen(tmp)]=bt->word;

	if(*bt->explain)
		fprintf(fp,"%s\t : %s\n",tmp,bt->explain);
	Save(bt->child,tmp,fp);
	tmp[strlen(tmp)-1]='\0';
	Save(bt->sibling,tmp,fp);
}

BTreeNode *Initialize(FILE *fp)
{
	char str1[MAX], str2[MAX];
	BTreeNode *ROOT=NULL;
	
	while(1)
	{
		if(feof(fp))
			break;

		fscanf(fp,"%s\t : %s\n",str1,str2);
		printf("%s %s \n",str1,str2);
		ROOT=Search(ROOT,str1,str2);
		printf("11\n");
	}

	return ROOT;
}
