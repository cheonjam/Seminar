#include "head.h"

BTreeNode *Search(BTreeNode *bt, char *word, char *explain)
{
	static int i=0;
	BTreeNode *tmp=NULL;

	if(!bt)
	{
		printf("10\n");
		bt=Insert(bt,word,explain);
		printf("12\n");
	}
	else if(*word > bt->word)
	{
		printf("15\n");
		bt->sibling=Search(bt->sibling,word,explain);
	}
	else if(!(*(word+1)))
	{
			printf("20\n");
		if(bt->word != *word)
		{
			printf("23\n");
			tmp=Insert(tmp,word,explain);
			tmp->sibling=bt;
			return tmp;
		}
		else if(*bt->explain)
		{
			printf("30\n");
			printf("\033[31mError : \033[0malready exist word\n");
		}
		else
			bt=Insert(bt,word,explain);
	}
	else if(*word == bt->word)
		bt->child=Search(bt->child,word+1,explain);
	else if(*word < bt->word)
	{
		tmp=Insert(tmp,word,explain);
		tmp->sibling=bt;
		return tmp;
	}

	return bt;
}

BTreeNode *Insert(BTreeNode *bt, char *word, char *explain)
{
	static int i=0;

	printf("I 53\n");
	if(*word=='\0')
		return NULL;
	
	if(bt)
	{
	printf("I 59\n");
		//strcpy(bt->explain,explain);
		memcpy(bt->explain,explain, 20);
		bt->explain[9]=0;
	printf("bt->explain %s\n",bt->explain);
		return bt;
	}

	printf("bt %d %d\n",sizeof(BTreeNode), bt);
	printf("asdfsadfsadfsadfsadfsadfas\n");
	bt=malloc(112);
	printf("bt2 %d\n",bt);
	memset(bt,'\0',sizeof(bt));
	printf("\n\n what\n");
		
	printf("I 68\n");
	bt->word=*word;
	if(!(*(word+1)))
		strcpy(bt->explain,explain);
	bt->child=Insert(bt->child,word+1,explain);

	printf("I 74\n");
	return bt;
}

